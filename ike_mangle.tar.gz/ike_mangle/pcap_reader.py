import dpkt, sys
import ike

f = open(sys.argv[1])
pcap = dpkt.pcap.Reader(f)

for ts, buf in pcap:
	eth = dpkt.ethernet.Ethernet(buf)
	ip  = eth.data
	udp = ip.data

	ikev1 = ike.IKE(udp.data)

	if isinstance(ikev1.data, ike.SA):
		print "%x" % ikev1.ispi
		print ikev1.next_payload
		print ikev1.exchange_type
		print ikev1.flag

		sec_assoc = ikev1.data

		print sec_assoc.next_payload
		print sec_assoc.domain_of_interpretation
		print sec_assoc.situation

		prop = sec_assoc.data

		print prop.next_payload
		print prop.protocol_id

		for trans in prop.data:
			print trans.next_payload
			print trans.transform_id

			for attr in trans.data:
				print attr.name
				print attr.value
f.close()
