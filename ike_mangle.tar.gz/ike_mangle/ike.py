"""Internet Security Association and Key Management Protocol."""

import dpkt, struct


EXCHANGE_TYPE = {
	0 : "None",
	1 : "Base",
	2 : "Identity protection",
	3 : "Authentication only",
	4 : "Aggressive",
	5 : "Informational"
}

FLAG = {
	0 : "None",
	5 : "Authentication Only",
	6 : "Commit",
	7 : "Encryption"
}

DOMAIN_OF_INTERPRETATION = {
	1 : "GDOI_PROTO_IPSEC_ESP",
}

class IKE(dpkt.Packet):
	__hdr__ = (
		('ispi', 'Q', 0),
		('rspi', 'Q', 0),
		('nxt', 'B', 0),
		('ver', 'B', 0),
		('ex_type', 'B', 0),
		('f', 'B', 0),
		('msg_id', 'I', 0),
		('len', 'I', 0)
		)
	def unpack(self, buf):
		dpkt.Packet.unpack(self, buf)

		self.next_payload  = NEXT_PAYLOAD.get(self.nxt, None)
		self.exchange_type = EXCHANGE_TYPE.get(self.ex_type, "UNKNOWN")
		self.flag          = FLAG.get(self.f, "UNKNOWN")

		if self.next_payload is not None and not isinstance(self.next_payload, str):
			self.data = self.next_payload(self.data)

	def __len__(self):
		return self.__hdr_len__ + len(self.data)

	def __str__(self):
		return self.pack_hdr() + str(self.data)

"""Security Association."""

SITUATION = {
	0 : "None",
	1 : "Identity Only",
	2 : "Secrecy",
	4 : "Integrity",
	6 : "Secrecy and Integrity"
}

class SA(dpkt.Packet):
	__hdr__ = (
		('nxt', 'B', 0),
		('res', 'B', 0),
		('len', 'H', 0),
		('doi', 'I', 0),
		('sit', 'I', 0),
		)
	def unpack(self, buf):
		dpkt.Packet.unpack(self, buf)

		self.next_payload             = NEXT_PAYLOAD.get(self.nxt, None)
		self.domain_of_interpretation = DOMAIN_OF_INTERPRETATION.get(self.doi, "UNKNOWN")
		self.situation				  = SITUATION.get(self.sit, "UNKNOWN")

		if self.next_payload is not None and not isinstance(self.next_payload, str):
			self.data = self.next_payload(self.data)
		else:
			self.data = Proposal(self.data)

	def __len__(self):
		return self.__hdr_len__ + len(self.data)

	def __str__(self):
		return self.pack_hdr() + str(self.data)

	def desc(self):
		return "Security Association"

""" Key Exchange."""

class KeyExchange(dpkt.Packet):
	__hdr__ = (
		('nxt', 'B', 0),
		('fill', 'B', 0),
		('len', 'H', 0),
		)
	def unpack(self, buf):
		dpkt.Packet.unpack(self, buf)

		self.next_payload = NEXT_PAYLOAD.get(self.nxt, None)
		self.key_data = [ hex(x) for x in struct.unpack(">%s" % ("B"*(self.len-4)), self.data[:self.len-4]) ]

		self.data = self.data[self.len-4:]

		if self.next_payload is not None and not isinstance(self.next_payload, str):
			self.data = self.next_payload(self.data)

	def __len__(self):
		return self.__hdr_len__ + len(self.data)

	def __str__(self):
		return self.pack_hdr() + str(self.data)

	def desc(self):
		return "Key Exchange"

""" Nonce."""

class Nonce(dpkt.Packet):
	__hdr__ = (
		('nxt', 'B', 0),
		('fill', 'B', 0),
		('len', 'H', 0),
		)
	def unpack(self, buf):
		dpkt.Packet.unpack(self, buf)

		self.next_payload = NEXT_PAYLOAD.get(self.nxt, None)

		self.nonce_data = [ hex(x) for x in struct.unpack(">%s" % ("B"*(self.len-4)), self.data[:self.len-4]) ]

		self.data = self.data[self.len-4:]

	def __len__(self):
		return self.__hdr_len__ + len(self.data)

	def __str__(self):
		return self.pack_hdr() + str(self.data)

	def desc(self):
		return "Nonce"

"""Proposal."""

PROTOCOL_ID = {
	1 : "ISAKMP"
}

class Proposal(dpkt.Packet):
	__hdr__ = (
		('nxt', 'B', 0),
		('res', 'B', 0),
		('len', 'H', 0),
		('num', 'B', 0),
		('pid', 'B', 0),
		('spis', 'B', 0),
		('transforms', 'B', 0),
		)
	def unpack(self, buf):
		dpkt.Packet.unpack(self, buf)
		self.next_payload = NEXT_PAYLOAD.get(self.nxt, None)
		self.protocol_id  = PROTOCOL_ID.get(self.pid, "UNKNOWN")

		# Parse transforms
		tmp_transforms = []
		transform_pos  = 0
		for num in range(0,self.transforms):
			transform = Transform(self.data[transform_pos:])
			tmp_transforms.append(transform)
			transform_pos += transform.len

		if len(tmp_transforms) > 0:
			self.data = tmp_transforms
		elif self.next_payload is not None and not isinstance(self.next_payload, str):
			self.data = self.next_payload(self.data)

	def __len__(self):
		return self.__hdr_len__ + len(self.data)

	def __str__(self):
		return self.pack_hdr() + str(self.data)

	def desc(self):
		return "Proposal"

"""Transform."""

TRANSFORM_ID = {
	1 : "KEY_IKE"
}

class Transform(dpkt.Packet):
	__hdr__ = (
		('nxt', 'B', 0),
		('res', 'B', 0),
		('len', 'H', 0),
		('trans', 'B', 0),
		('tid', 'B', 0)
	)
	def unpack(self, buf):
		dpkt.Packet.unpack(self, buf)
		
		self.next_payload = NEXT_PAYLOAD.get(self.nxt, None)
		self.transform_id = TRANSFORM_ID.get(self.tid, "UNKNOWN")

		# handle gap before the transforms
		self.data = self.data[2:]
		self.len -= 2

		attributes = []
		total_len = self.len-self.__hdr_len__
		pos = 0
		while total_len > 0:
			trans_attr = TransformAttribute(self.data[pos:])
			pos += trans_attr.__hdr_len__ + trans_attr.__ext_len__
			total_len = total_len-(trans_attr.__hdr_len__ + trans_attr.__ext_len__)
			attributes.append(trans_attr)

		if len(attributes) > 0:
			self.data = attributes

	def __len__(self):
		return self.__hdr_len__ + len(self.data)

	def __str__(self):
		return self.pack_hdr() + str(self.data)

	def desc(self):
		return "Transform"

"""Transform Attribute."""

ATTR_TYPES = {  1 : "Encryption Algorithm",
				2 : "Hash Algorithm",
				3 : "Authentication Method",
				4 : "Group Description",
				5 : "Group Type",
				6 : "Group Prime/Irreducible Polynomial",
				7 : "Group Generator One",
				8 : "Group Generator Two",
				9 : "Group Curve A",
			   10 : "Group Curve B",
			   11 : "Life Type",
			   12 : "Life Duration",
			   13 : "PRF",
			   14 : "Key Length",
			   15 : "Field Size",
			   16 : "Group Order" }

ENCRYPTION_ALGORITHM = {
	1 : "DES-CBC",
	2 : "IDEA-CBC",
	3 : "Blowfish-CBC",
	4 : "RC5-CBC",
	5 : "3DES-CBC",
	6 : "CAST-CBC",
	7 : "AES-CBC",
	8 : "Camellia-CBC"
}

HASH_ALGORITHM = {
	1 : "MD5",
	2 : "SHA",
	3 : "Tiger",
	4 : "SHA2-256",
	5 : "SHA2-384",
	6 : "SHA2-512"
}

ATTR_MAP = {
	1 : ENCRYPTION_ALGORITHM,
	2 : HASH_ALGORITHM,
}

LENGTHS = { 1 : ">B", 2 : ">H", 4 : ">I", 8 : ">Q" }
TV		= 128
TLV		= 0

class TransformAttribute(dpkt.Packet):
	__hdr__ = (
		('tif', 'B', 0),
		('att', 'B', 0)
	)
	def unpack(self, buf):
		dpkt.Packet.unpack(self, buf)

		self.name = ATTR_TYPES.get(self.att)
		
		if self.tif == TV:
			self._tv()
		elif self.tif == TLV:
			self._tlv()

		self.value = self.val
		if ATTR_MAP.has_key(self.att):
			self.value = ATTR_MAP.get(self.att).get(self.val, "UNKNOWN")

	def __len__(self):
		return self.__hdr_len__ + self.__ext_len__ + len(self.data)

	def __str__(self):
		return self.pack_hdr() + str(self.data)

	def _tv(self):
		( self.val, ) = struct.unpack(">H", self.data[:2])

		self.data = self.data[2:]
		self.__ext_len__ = 2

	def _tlv(self):
		( self.len, ) = struct.unpack(">H", self.data[:2])
		( self.val, ) = struct.unpack(LENGTHS.get(self.len), self.data[2:2+self.len])

		self.data = self.data[2+self.len:]
		self.__ext_len__ = 2+self.len

# next payload
NEXT_PAYLOAD = {
	0 : None,
	1 : SA,
	2 : Proposal,
	3 : Transform,
	4 : KeyExchange,
	5 : "Identification",
	6 : "Certificate",
	7 : "Certificate Request",
	8 : "Hash",
	9 : "Signature",
	10 : Nonce,
	11 : "Notification",
	12 : "Delete",
	13 : "Vendor ID",
	14 : "",
	15 : "SAK, SA KEK Payload",
	16 : "SAT, SA TEK Payload",
	17 : "Key Download",
	18 : "Sequence Number",
	19 : "Proof of Possession",
	20 : "NAT-D, NAT Discovery",
	21 : "NAT-OA, NAT Original Address"
}
