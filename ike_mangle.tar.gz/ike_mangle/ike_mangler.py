import struct

LENGTHS = { 1 : ">B", 2 : ">H", 4 : ">I", 8 : ">Q" }

def read_section(data, start, length):
    """ reads and unpacks a section of a binary string """
    ( value, ) = struct.unpack(LENGTHS.get(length, ">%s" % ("B" * length)), data[start:start+length])
    return value

def replace_section(data, start, value, length=None):
    """ replace  a section of a binary string with the given value,
       the length of the section to be replaced can be specified with length """
    if length is None:
	length = len(value)
    data = "%s%s%s" % ( data[:start], struct.pack(LENGTHS.get(length, ">%s" % ("B" * length)), value), data[start+length:] )
    return data

# ISAKMP starts at byte 43 (data[42:])
def no_encryption(data):
    """ set the encryption bit in an IKEv1 packet to 0 """
    flags = read_section(data, 19, 1) # flags are the 19th byte
    # encryption bit is the lowest order bit, when set the flags have an odd value
    if flags % 2 == 1:
	flags = flags-1
	data = replace_section(data, 19, flags, length=1)
    return data

def rem_id(data):
    " remove the main mode ID payload "
    # IDENTIFICATION => 5
    return rem_next(data, 5);

def rem_hash(data):
    " remove the quick mode HASH payload "
    # HASH => 8
    return rem_next(data, 8);

# IKEv2 only (expiremental)
def rem_enc_and_auth(data):
    # Encrypted and Authenticated => 46
    return rem_next(data, 46);

def rem_next(data, np):
    " remove the next payload if the payload type (np) matches "
    next_payload = read_section(data, 16, 1)
    if next_payload == np:
	data = data[:28]
    # adjust the length field
    data = replace_section(data, 24, len(data), length=4)
    return data
